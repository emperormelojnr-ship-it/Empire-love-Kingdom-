EMPIRE LOVE KINGDOM — FIRST WEBSITE PROTOTYPE

Files:
- index.html: single-file, responsive website prototype.

How to preview:
1. Download index.html to a computer or phone.
2. Open it in a modern web browser.
3. Try the city filters, Like buttons, signup/login screens, premium checkout preview, and advertiser enquiry form.

Important limitations:
- This is a front-end prototype only. Demo profiles are fictional sample cards.
- It does not create real accounts, save personal details to a server, provide real messaging, or process payments.
- Payment buttons are deliberately simulated. Do not collect real payment details using this prototype.
- Before public launch, connect a secure backend/database, server-side authentication, age/identity and moderation workflows, reporting/blocking, privacy and terms pages, and verified payment integrations for M-Pesa and cards.
- Do not collect sensitive personal information until a proper privacy and security review is completed.
- Confirm applicable Kenyan legal requirements, provider policies, and app/web advertising rules before launch.

Suggested next milestone:
Build the backend and database (users, profiles, preferences, likes/matches, reports/blocks, subscriptions, payment records, and advertiser enquiries), then connect the frontend to it.
